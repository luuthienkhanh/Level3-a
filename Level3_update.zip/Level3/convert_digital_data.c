#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include"adc.h"
#include"api.h"
#include"convert_digital_data.h"
#include"DisplayLED.h"

static uint8_t lcd_buffer[] = "    WXYZ ";
extern int timer_flag;
extern volatile uint16_t gADC_Result;
extern unsigned int data_LED;
unsigned long current=0;
unsigned long previous=0;
int previous_LED=0;
int current_LED=0;

extern int decrease;

void convert_digital_data(void){
	 if (timer_flag == 1)
	    {   unsigned long a;
		/* Start an A/D conversion */
		ADC_Start();
		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);
		/* Clear ADC flag */
		Adc_Status = 0;
                previous=current;
		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR >> 6;
		a= (unsigned long)(gADC_Result);
		a= a*330/1023;
		current=a;
		//if ((previous-current)==1)
		//{
			//decrease=1;
			//offLED();
		//}
		
	
		previous_LED=current_LED;
		if (0<=a&&a<=14){
			data_LED=0;
		}else if (15<=a&&a<=27){
			data_LED=1;
		}else if (28<=a&&a<=54){
			data_LED=2;
		}else if (55<=a&&a<=82){
			data_LED=3;
		}else if (83<=a&&a<=110){
			data_LED=4;
		}else if (111<=a&&a<=136){
			data_LED=5;
		}else if (137<=a&&a<=164){
			data_LED=6;
		}else if (165<=a&&a<=192){
			data_LED=7;
		}else if (193<=a&&a<=220){
			data_LED=8;
		}else if (221<=a&&a<=247){
			data_LED=9;
		}else if (248<=a&&a<=274){
			data_LED=10;
		}else if (275<=a&&a<=302){
			data_LED=11;
		}else if (303<=a&&a<=330){
			data_LED=12;
		}
		current_LED=data_LED;
		if (previous_LED>current_LED)
		{
			offLED();
		}
		DisplayLED(data_LED);
		
		/* Convert ADC result into a character string, and store in the local */
		lcd_buffer[4] = (a/100+'0');
		lcd_buffer[5] = '.';
		lcd_buffer[6] = ((a%100)/10+'0');
		lcd_buffer[7] = ((a%100)%10+'0');
		DisplayLCD(LCD_LINE7, (const uint8_t*)lcd_buffer);
	    }
	    else
	    {
                /* Do nothing */
	    }
	}
	
	