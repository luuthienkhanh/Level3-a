#include "iodefine.h"
#include "api.h"
#include "ports.h"
#include "DisplayLED.h"

void DisplayLED(unsigned int data){
	switch (data){
		        case 12:   
                                    P4_bit.no2 = 0;
                        case 11:
                                    
                                    P6_bit.no3 = 0;
                        case 10:
                                    
                                    P4_bit.no3 = 0;
                        case 9:
                                    
                                    P6_bit.no4 = 0;
                        case 8:
                                    
                                    P4_bit.no4 = 0;
                        case 7:
                                    
                                    P6_bit.no5 = 0;
                        case 6:
                                    
                                    P4_bit.no5 = 0;
                        case 5:
                                    
                                    P6_bit.no6 = 0;
                        case 4:
                                    
                                    P15_bit.no2 = 0;
                        case 3:
                                    
                                    P6_bit.no7 = 0;
                        case 2:
                                    
                                    P10_bit.no1 = 0;
                        case 1:
                                    
                                    P6_bit.no2 = 0;
                        default:
                         
                                    break;

	}
}
	