#include "iodefine.h"
#include "api.h"
#include "ports.h"
#include "DisplayLED.h"

/******************************************************************************
* Function Name: DisplayLED
* Description  : Display LED
* Arguments    : none
* Return Value : none
******************************************************************************/
extern int LED[12];


void check_LED(unsigned int data){
	int i;
	if (1<=data){
		for (i=0;i<=data;i++){
		LED[i]=0;
		//break;
	}}else offLED();	
	
}