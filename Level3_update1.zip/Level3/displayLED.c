#include "iodefine.h"
#include "api.h"
#include "ports.h"
#include "DisplayLED.h"

/******************************************************************************
* Function Name: DisplayLED
* Description  : Display LED
* Arguments    : none
* Return Value : none
******************************************************************************/
extern int LED[12];

void DisplayLED(void){
		    
                                    P4_bit.no2 = LED[11];
                       
                                    
                                    P6_bit.no3 = LED[10];
                      
                                    
                                    P4_bit.no3 = LED[9];
                      
                                    
                                    P6_bit.no4 = LED[8];
                       
                                    
                                    P4_bit.no4 = LED[7];
                        
                                    
                                    P6_bit.no5 = LED[6];
                            
                                    P4_bit.no5 = LED[5];
                       
                                    
                                    P6_bit.no6 = LED[4];
                       
                                    
                                    P15_bit.no2 =LED[3]; 
                       
                                    
                                    P6_bit.no7 = LED[2];
                       
                                    
                                    P10_bit.no1 = LED[1];
                       
                                    
                                    P6_bit.no2 = LED[0];
                                   

	
}

