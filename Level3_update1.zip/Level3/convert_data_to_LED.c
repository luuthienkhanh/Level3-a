#include "convert_data_to_LED.h"
#include"api.h"
#include"check_LED.h"
#include"DisplayLED.h"
int previous_LED=0;
int current_LED=0;
extern float a;
extern unsigned int data_LED;
extern unsigned long b;
int data_range[13]={14,27,54,82,110,136,164,192,220,247,274,302,331};
/******************************************************************************
* Function Name: convert_digital_data
* Description  : convert digital data
* Arguments    : none
* Return Value : none
******************************************************************************/


void convert_data_to_LED(void){
	        int i=0;
		previous_LED=current_LED;//update previous LED
		for (i=0;i<=12;i++){
			if(b<data_range[i]){
				data_LED=i;
				break;
			}
			
		}
		current_LED=data_LED;
		
		check_LED(data_LED);
		DisplayLED();
		if (previous_LED>current_LED) // if previous_LED>current_LED turn off all LED 
		{
			offLED();
		}
}