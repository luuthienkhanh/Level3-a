#include "convert_data_to_LED.h"
#include"api.h"
int previous_LED=0;
int current_LED=0;
extern float a;
extern unsigned int data_LED;
/******************************************************************************
* Function Name: convert_digital_data
* Description  : convert digital data
* Arguments    : none
* Return Value : none
******************************************************************************/
void convert_data_to_LED(void){
		previous_LED=current_LED;//update previous LED
		if ((0<=a)&&(a<=0.14)){
			data_LED=0;
		}else if ((0.15<=a)&&(a<=0.27)){
			data_LED=1;
		}else if ((0.28<=a)&&(a<=0.54)){
			data_LED=2;
		}else if ((0.55<=a)&&(a<=0.82)){
			data_LED=3;
		}else if((0.83<=a)&&(a<=1.10)){
			data_LED=4;
		}else if ((1.11<=a)&&(a<=1.36)){
			data_LED=5;
		}else if ((1.37<=a)&&(a<=1.64)){
			data_LED=6;
		}else if ((1.65<=a)&&(a<=1.92)){
			data_LED=7;
		}else if ((1.93<=a)&&(a<=2.20)){
			data_LED=8;
		}else if ((2.21<=a)&&(a<=2.47)){
			data_LED=9;
		}else if ((2.48<=a)&&(a<=2.74)){
			data_LED=10;
		}else if ((2.75<=a)&&(a<=3.02)){
			data_LED=11;
		}else if ((3.03<=a)&&(a<=3.30)){
			data_LED=12;
		}
		current_LED=data_LED;
		if (previous_LED>current_LED) // if previous_LED>current_LED turn off all LED 
		{
			offLED();
		}
}